<?php $__env->startSection('title'); ?>
    <title>EXAM CRUD</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
    <h1>It's a Quiz Page</h1>
    <h2>Quiz Title: <?php echo e($quiz->title); ?></h2>
    <h3>Exam Time: <?php echo e($quiz->duration); ?> Minutes or <?php echo e($quiz->duration*60); ?> Seconds</h3>

    <div class="text-center">
        <form method="post" id='examsQuestion' action="#">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="quiz_id" value="<?php echo e($quiz->id); ?>" readonly required>
            <input id="start_time" type="hidden" name="start_time" value="<?php echo e($start_time); ?>" readonly required>
            <?php
            $i=1;
            ?>
            <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <select name="answer[<?php echo e($i++); ?>]" class="form-control" required>
                <option selected disabled value>Question: <?php echo e($question->question); ?></option>
                    <option value="option_a"><?php echo e($question->option_a); ?></option>
                    <option value="option_b"><?php echo e($question->option_b); ?></option>
                    <option value="option_c"><?php echo e($question->option_c); ?></option>
                    <option value="option_d"><?php echo e($question->option_d); ?></option>
                </select>

                <hr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>

<script>
    $("#examsQuestion").submit(function(e){
        e.preventDefault();
        var formdata = $(this).serialize();

        $.ajax({
                type:'POST',
               url:"<?php echo e(route('store.answer')); ?>",
               data: formdata,
               dataType: 'json',
               headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
               success:function(data) {
                if (data.message ==="success") {
                    Swal.fire(data.data).then((req) =>{
                        location.href = "<?php echo e(route('results')); ?>"
                    })

                }else{
                    Swal.fire(data.data)
                }
                $("#addExam").get(0).reset();

            }
        });
    });
  </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\php\quiz\resources\views/user/give-quiz.blade.php ENDPATH**/ ?>