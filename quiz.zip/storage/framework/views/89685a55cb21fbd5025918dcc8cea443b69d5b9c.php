<?php $__env->startSection('title'); ?>
    <title>My Results</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
    <h1>Result List</h1>
    <div class="text-center">
        <table class="table">
            <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Title</th>
                <th scope="col">Quiz Score</th>
                <?php if(session('user_role')=='admin'): ?>
                    <th scope="col">User Score</th>
                    <th scope="col">User Name</th>
                <?php else: ?>
                    <th scope="col">My Score</th>
                <?php endif; ?>
                <th scope="col">Date</th>
            </tr>
            </thead>
            <tbody>
            <?php
                $sl=1;
            ?>
            <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($sl++); ?></th>
                    <td><?php echo e($result->title); ?></td>
                    <td><?php echo e($result->quiz_score); ?></td>
                    <td><?php echo e($result->achieved_score); ?></td>
                    <?php if(session('user_role')=='admin'): ?>
                        <td><?php echo e($result->username); ?></td>
                    <?php endif; ?>
                    <td><?php echo e($result->created_at); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\php\quiz\resources\views/user/result-page.blade.php ENDPATH**/ ?>