<?php $__env->startSection('title'); ?>
    <title>Dashboard</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
    <h1>Exam List</h1>
    <div class="text-center">
        <table class="table">
            <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Title</th>
                <th scope="col">From</th>
                <th scope="col">To</th>
                <th scope="col">Duration</th>
                <th scope="col">Action</th>
            </tr>
            </thead>
            <tbody>
            <?php
            $sl=1;
            ?>
            <?php $__currentLoopData = $quiz_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($sl++); ?></th>
                    <td><a href="/add-question/<?php echo e($quiz->id); ?>" target="_blank"><?php echo e($quiz->title); ?></a></td>
                    <td><?php echo e($quiz->from_time); ?></td>
                    <td><?php echo e($quiz->to_time); ?></td>
                    <td><?php echo e($quiz->duration); ?> minutes</td>
                    <td><a class="btn btn-success" href="http://">EDIT</a> <div class="btn btn-danger del" delete-id="<?php echo e($quiz->id); ?>" >DELETE</div> </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>

<script>
    $('.del').click(function(){
        var id = $(this).attr('delete-id');

        Swal.fire({
        title: 'Do you want to delete this question?',
        showCancelButton: true,
        confirmButtonText: 'YES',
        }).then((result) => {

        if (result.isConfirmed) {

            $.ajax({
                type:'post',
                url: "<?php echo e(route('store.delete')); ?>",
                dataType:'json',
                data:{id:id},
                headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success : function(data){
                    Swal.fire(data.data).then((result) => {
                        // Reload the Page
                        location.reload();
                        });
                }
            });


        }
        })

    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\php\quiz\resources\views/admin/quiz-list.blade.php ENDPATH**/ ?>